%% ep2
clear all
close all
clc
format long 
az=dlmread('D:\D\lesson\term 6\jheodetic\project\4_6024070702158580249\project_G5_materials\ep1\Azimuth.txt');
h_angle=dlmread('D:\D\lesson\term 6\jheodetic\project\4_6024070702158580249\project_G5_materials\ep1\Horizintal_Angles.txt');
horizontal_distance=dlmread('D:\D\lesson\term 6\jheodetic\project\4_6024070702158580249\project_G5_materials\ep1\horizontal_distance.txt');
ang=dlmread('D:\D\lesson\term 6\jheodetic\project\part_1\part_1\Angles.txt');
dist=dlmread('D:\D\lesson\term 6\jheodetic\project\part_1\part_1\Distances.txt');

XY=[9498.2600 78594.9055;1.036757102703296*10^4 7.591320896809051*10^4;0.930041772335932*10^4 7.530673940701323*10^4;7.115104587912532*10^3 7.572360284452353*10^4;0.720664412517403*10^4 7.890786685116652e+04;6.633265995427694*10^3 7.670152330922795*10^4;8.401875515180878*10^3 7.660780757881723*10^4];
%%1
r_ang=45;
r_d=100;
for i=1:length(ang);
s(i)=(ang(i)-r_ang)^2;
d(i)=(dist(i)-r_d)^2;
end
sig_n=sum(s)/length(ang);
d_n=sum(d)/length(ang);

alpha=input ('pls Enter value of alpha: ');
alpha2=alpha/2;
sig=dms2degrees([0 0 0.5]);
sig=sig*sqrt(2);
d=0.005;
%%azmone mean
meandis=mean(dist);
meanang=mean(ang);
T_dis=(meandis-r_d)/(d/sqrt(length(dist)));
k_alpha_dis=norminv(1-alpha2,0,1);	
if T_dis<= k_alpha_dis 
    if -(  k_alpha_dis)<=T_dis
    
        disp('There is not Sys Error in Distances!')
else
      disp('There is Sys Error in Distances!')
end
end
%%zavie
T_ang=(meanang-r_ang)/(sig/sqrt(length(ang)));
k_alpha_ang=norminv(1-alpha2,0,1);	
if T_ang<= k_alpha_ang 
    if -( k_alpha_ang)<=T_ang
        disp('There is not Sys Error in Angles!')
else
      disp('There is Sys Error in Angles!')
end
end

%%azmone varianc

Ta=(length(ang)*sig_n)/(sig^2);
Td=(length(dist)*d_n)/(d^2);

H12=chi2inv(1-alpha2,length(dist));
H1=chi2inv(alpha2,length(dist));

if H1<=Td
    if Td<=H12
  disp('deghate esmi(tool) is true!!')
    else
    disp('deghate esmi(tool) is wrong!!')
        
    end
end

H122=chi2inv(1-alpha2,length(ang));
H11=chi2inv(alpha2,length(ang));

if H11<=Ta 
    if Ta<=H122
    disp('deghate esmi(zavie) is true!!')
else
    disp('deghate esmi(zavie) is wrong!!')
    
end
end


%%2
dis=@(x1,x2,y1,y2) sqrt((x2-x1)^2+(y2-y1)^2);
azimuth=@(x1,x2,y1,y2) atan2((x2-x1),(y2-y1));
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2);
    ds1(i,1) = dis(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
end
for i = 1: numel(h_angle(:,1))
    n1 = h_angle(i,1);
    n2 = h_angle(i,2);
    n3 = h_angle(i,3);
    angle(i,1) = azimuth(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2))-azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if angle(i,1)<0
angle(i,1) = angle(i,1)+2*pi;
end
end
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    AZ(i,1) = azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if AZ(i,1)<0
AZ(i,1) = AZ(i,1)+2*pi;
end
end
moshahede=[horizontal_distance(:,3);deg2rad(h_angle(:,4));deg2rad(az(:,3));XY(1,1);XY(1,2)];
mohasebati=[ds1;angle;AZ;XY(1,1);XY(1,2)];
dL=moshahede-mohasebati;
deghat_z=deg2rad(dms2degrees([0 0 0.5]));

deghat=0.005;
for i = 1:length (horizontal_distance)
w(i,i) = 1/deghat^2;
end
n=length(w);
m=length(h_angle);
for i = n+1:n+m+1;
w(i,i) = 1/deghat_z^2;
end
dxy=[0.000004 0.0000001;0.0000001 0.00000225];
w(length(w)+1:length(w)+2,length(w)+1:length(w)+2)=dxy^-1;
diff_dist = @(f1,f2,s) -(f1 - f2)/s;
diff_az_x = @(x1,x2,y1,y2)(imag(x1) - imag(x2) - real(y1) + real(y2))/((imag(x1) - imag(x2) - real(y1) + real(y2))^2 + (imag(y1) - imag(y2) + real(x1) - real(x2))^2);
diff_az_y = @(x1,x2,y1,y2)(imag(y1) - imag(y2) + real(x1) - real(x2))/((imag(x1) - imag(x2) - real(y1) + real(y2))^2 + (imag(y1) - imag(y2) + real(x1) - real(x2))^2);
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2); 
    s1 = ds1(i,1);
    g1 = diff_dist(XY(n1,1),XY(n2,1),s1);
    g2 = diff_dist(XY(n1,2),XY(n2,2),s1);
    A(i,2*n1-1:2*n1) = [-g1 -g2];  
    A(i,2*n2-1:2*n2) = [+g1 +g2]; 
end
n = numel(A(:,1));
for i = 1: numel(h_angle(:,1))
    n1 = h_angle(i,1);
    n2 = h_angle(i,2);
    n3 = h_angle(i,3);
    g1 = diff_az_x(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g2 = diff_az_y(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g3 = -diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = -diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A(i+n,2*n1-1:2*n1) = [-(g1+g3) -(g2+g4)];  
    A(i+n,2*n2-1:2*n2) = [g3 g4]; 
    A(i+n,2*n3-1:2*n3) = [g1 g2];
end
n = numel(A(:,1));
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    g3 = diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A(i+n,2*n1-1:2*n1) = [-g3 -g4];  
    A(i+n,2*n2-1:2*n2) = [g3 g4]; 
end
n = numel(A(:,1));
A(n+1:n+2,1*2-1:1*2)= [1 0;0 1];
dx = inv(A'*w*A)*A'*w*(dL);
    
for i=1:7
    XY(i,1) = XY(i,1) + dx(2*i-1);   
    XY(i,2) = XY(i,2) + dx(2*i); 
end
Tim=1
while norm(dx) > 10^-6
    clear A
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2);
    ds1(i,1) = dis(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
end
for i = 1: numel(h_angle(:,1))
    n1 = h_angle(i,1);
    n2 = h_angle(i,2);
    n3 = h_angle(i,3);
    angle(i,1) = azimuth(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2))-azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if angle(i,1)<0
angle(i,1) = angle(i,1)+2*pi;
end
end
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    AZ(i,1) = azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if AZ(i,1)<0
AZ(i,1) = AZ(i,1)+2*pi;
end
end
moshahede=[horizontal_distance(:,3);deg2rad(h_angle(:,4));deg2rad(az(:,3));9498.26000000000;78594.9055000000];
mohasebati=[ds1;angle;AZ;XY(1,1);XY(1,2)];
dL=moshahede-mohasebati;
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2); 
    s1 = ds1(i,1);
    g1 = diff_dist(XY(n1,1),XY(n2,1),s1);
    g2 = diff_dist(XY(n1,2),XY(n2,2),s1);
    A(i,2*n1-1:2*n1) = [-g1 -g2];  
    A(i,2*n2-1:2*n2) = [+g1 +g2]; 
end
n = numel(A(:,1));
for i = 1: numel(h_angle(:,1))
    n1 = h_angle(i,1);
    n2 = h_angle(i,2);
    n3 = h_angle(i,3);
    g1 = diff_az_x(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g2 = diff_az_y(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g3 = -diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = -diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A(i+n,2*n1-1:2*n1) = [-(g1+g3) -(g2+g4)];  
    A(i+n,2*n2-1:2*n2) = [g3 g4]; 
    A(i+n,2*n3-1:2*n3) = [g1 g2];
end
n = numel(A(:,1));
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    g3 = diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A(i+n,2*n1-1:2*n1) = [-g3 -g4];  
    A(i+n,2*n2-1:2*n2) = [g3 g4]; 
end
n = numel(A(:,1));
A(n+1:n+2,1*2-1:1*2)= [1 0;0 1];
dx = (A'*w*A)^-1*A'*w*(dL);
   Tim=Tim+1 ;
for i=1:7
    XY(i,1) = XY(i,1) + dx(2*i-1);   
    XY(i,2) = XY(i,2) + dx(2*i); 
end    
end

v = A*dx-(dL);
% X2=[XY(1,1);XY(1,2);XY(2,1);XY(2,2);XY(3,1);XY(3,2);XY(4,1);XY(4,2);XY(5,1);XY(5,2);XY(6,1);XY(6,2);XY(7,1);XY(7,2)];
% 
% M10=[X2(1,1) X2(2,1);X2(3,1) X2(4,1);X2(5,1) X2(6,1);X2(7,1) X2(8,1);X2(9,1) X2(10,1);X2(11,1) X2(12,1);X2(13,1) X2(14,1)];
% Q10=[0 1 1 1 1 1 1;1 0 0 0 1 0 0;1 0 0 0 1 0 0;1 0 0 0 1 0 0;1 1 1 1 0 1 1;1 0 0 0 1 0 0;1 0 0 0 1 0 0];

figure(35)
% gplot(Q10,M10,'-o')
% hold on
%%tool
vd=[1;2 ;3;4;5;6;7;8;9;10;11;12];
vz=[1;2 ;3;4;5;6;7;8;9;10;11;12;13;14;15];
plot(vd,v(1:12),'m')
xlabel('shomare tool')
ylabel('baghimande tool(m)')
title('nemodare baghimande tool')
figure(36)
plot(vz,v(13:27),'c')
xlabel('shomare zavie')
ylabel('baghimande zavie(s)')
title('nemodare baghimande zavie')

T1=(v'*w*v);
X12=chi2inv(0.05/2,(30-14));
X122=chi2inv(1-(0.05/2),(30-14));
if X12<=T1
    if T1<=X122
  disp('accept H0(ep2)- No big data(1)!')
    else
    disp('reject H0(ep2)- big data(1)!')    
    end
end
A1=A; 
AC=A;
 dL1=dL;
  dLC=dL;

 L_mosh=moshahede;
L_moh=mohasebati;
W=w;
WC=w;

V=v;
%
QXX=inv(A'*w*A);
QLL=A*QXX*A';
QVV=inv(w)-QLL;

for j=1:length(w)
    for i=1:length(w)
    if i==j
    c1(i,j)=1;
    else
    c1(i,j)=0;
    end
    end
end

for i=1:length(w)
    w1(i)=real(((c1(i,:))*((w))*(v))/(sqrt(((c1(i,:))*((w))*abs(QVV)*((w))*(c1(:,i)))))); 
end

N= norminv(1-(0.05/2),0,1);
 temp5=[];
   for j=1:length(w)
   if w1(1,j)>N | w1(1,j)<-(N)
 fprintf('The range data is %f  \n',j)
 temp5=[temp5 j];
   else
       disp('accept H0(ep1)!')
       end
   end
   for i=1:numel(w1)
   w2(1,i)=abs(w1(1,i));
   end
   mx=max(w2)
mxx=find(max(w2(1,:))==w2(1,:));

A(mxx,:)=[];
dL(mxx,:)=[];
w(mxx,:)=[];
w(:,mxx)=[];
w1(:,mxx)=[];
w2(:,mxx)=[];
c1(mxx,:)=[];
c1(:,mxx)=[];
%
ang_h=h_angle;
ang_z=h_angle;

ang_h(mxx-length(horizontal_distance),:)=[];
dx1= inv(A'*w*A)*A'*w*(dL);

while norm(dx1) > 10^-6
    clear A
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2);
    ds1(i,1) = dis(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
end
for i = 1: numel(ang_h(:,1))
    n1 = ang_h(i,1);
    n2 = ang_h(i,2);
    n3 = ang_h(i,3);
    angle1(i,1) = azimuth(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2))-azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if angle1(i,1)<0
angle1(i,1) = angle1(i,1)+2*pi;
end
end
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    AZ(i,1) = azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if AZ(i,1)<0
AZ(i,1) = AZ(i,1)+2*pi;
end
end
moshahede1=[horizontal_distance(:,3);deg2rad(ang_h(:,4));deg2rad(az(:,3));9498.26000000000;78594.9055000000];
mohasebati1=[ds1;angle1;AZ;XY(1,1);XY(1,2)];
dL0=moshahede1-mohasebati1;
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2); 
    s1 = ds1(i,1);
    g1 = diff_dist(XY(n1,1),XY(n2,1),s1);
    g2 = diff_dist(XY(n1,2),XY(n2,2),s1);
    A(i,2*n1-1:2*n1) = [-g1 -g2];  
    A(i,2*n2-1:2*n2) = [+g1 +g2]; 
end
n = numel(A(:,1));
for i = 1: numel(ang_h(:,1))
    n1 = ang_h(i,1);
    n2 = ang_h(i,2);
    n3 = ang_h(i,3);
    g1 = diff_az_x(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g2 = diff_az_y(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g3 = -diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = -diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A(i+n,2*n1-1:2*n1) = [-(g1+g3) -(g2+g4)];  
    A(i+n,2*n2-1:2*n2) = [g3 g4]; 
    A(i+n,2*n3-1:2*n3) = [g1 g2];
end
n = numel(A(:,1));
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    g3 = diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A(i+n,2*n1-1:2*n1) = [-g3 -g4];  
    A(i+n,2*n2-1:2*n2) = [g3 g4]; 
end
n = numel(A(:,1));
A(n+1:n+2,1*2-1:1*2)= [1 0;0 1];
dx1= (A'*w*A)^-1*A'*w*(dL0);
   Tim=Tim+1 ;
for i=1:7
    XY(i,1) = XY(i,1) + dx1(2*i-1);   
    XY(i,2) = XY(i,2) + dx1(2*i); 
end    
end
v = A*dx1-(dL0);
 T1=(v'*w*v);
X12=chi2inv(0.05/2,(length(A)-14));
X122=chi2inv(1-(0.05/2),(length(A)-14));
if X12<=T1
    if T1<=X122
  disp('accept H0(ep1)- No big data(1)!')
    else
    disp('reject H0(ep1)- big data(1)!')    
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%2
QXX=inv(A'*w*A);
QLL=A*QXX*A';
QVV=inv(w)-QLL;
%

for j=1:length(w)
    for i=1:length(w)
    if i==j
    c1(i,j)=1;
    else
    c1(i,j)=0;
    end
    end
end

for i=1:length(w)
    w1(i)=real(((c1(i,:))*((w))*(v))/(sqrt(((c1(i,:))*((w))*abs(QVV)*((w))*(c1(:,i)))))); 
end

N= norminv(1-(0.05/2),0,1);
 temp5=[];
   for j=1:length(w)
   if w1(1,j)>N | w1(1,j)<-(N)
 fprintf('The range data is %f  \n',j)
 temp5=[temp5 j];
   else
       disp('accept H0(ep1)!')
       end
   end
   for i=1:numel(w1)
   w2(1,i)=abs(w1(1,i));
   end
   mx1=max(w2)
mxx1=find(max(w2(1,:))==w2(1,:));

A(mxx1,:)=[];
dL(mxx1,:)=[];
w(mxx1,:)=[];
w(:,mxx1)=[];
w1(:,mxx1)=[];
w2(:,mxx1)=[];
c1(mxx1,:)=[];
c1(:,mxx1)=[];
%
ang_h(mxx1-length(horizontal_distance),:)=[];
dx1= inv(A'*w*A)*A'*w*(dL);
%
while norm(dx1) > 10^-6
    clear A
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2);
    ds1(i,1) = dis(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
end
for i = 1: numel(ang_h(:,1))
    n1 = ang_h(i,1);
    n2 = ang_h(i,2);
    n3 = ang_h(i,3);
    angle2(i,1) = azimuth(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2))-azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if angle2(i,1)<0
angle2(i,1) = angle2(i,1)+2*pi;
end
end
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    AZ(i,1) = azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if AZ(i,1)<0
AZ(i,1) = AZ(i,1)+2*pi;
end
end
moshahede1=[horizontal_distance(:,3);deg2rad(ang_h(:,4));deg2rad(az(:,3));9498.26000000000;78594.9055000000];
mohasebati1=[ds1;angle2;AZ;XY(1,1);XY(1,2)];
dL0=moshahede1-mohasebati1;
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2); 
    s1 = ds1(i,1);
    g1 = diff_dist(XY(n1,1),XY(n2,1),s1);
    g2 = diff_dist(XY(n1,2),XY(n2,2),s1);
    A(i,2*n1-1:2*n1) = [-g1 -g2];  
    A(i,2*n2-1:2*n2) = [+g1 +g2]; 
end
n = numel(A(:,1));
for i = 1: numel(ang_h(:,1))
    n1 = ang_h(i,1);
    n2 = ang_h(i,2);
    n3 = ang_h(i,3);
    g1 = diff_az_x(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g2 = diff_az_y(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g3 = -diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = -diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A(i+n,2*n1-1:2*n1) = [-(g1+g3) -(g2+g4)];  
    A(i+n,2*n2-1:2*n2) = [g3 g4]; 
    A(i+n,2*n3-1:2*n3) = [g1 g2];
end
n = numel(A(:,1));
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    g3 = diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A(i+n,2*n1-1:2*n1) = [-g3 -g4];  
    A(i+n,2*n2-1:2*n2) = [g3 g4]; 
end
n = numel(A(:,1));
A(n+1:n+2,1*2-1:1*2)= [1 0;0 1];
dx1= (A'*w*A)^-1*A'*w*(dL0);
   Tim=Tim+1 ;
for i=1:7
    XY(i,1) = XY(i,1) + dx1(2*i-1);   
    XY(i,2) = XY(i,2) + dx1(2*i); 
end    
end
%
v = A*dx1-(dL0);
 T1=(v'*w*v);
X12=chi2inv(0.05/2,(length(A)-14));
X122=chi2inv(1-(0.05/2),(length(A)-14));
if X12<=T1
    if T1<=X122
  disp('accept H0(ep1)- No big data(1)!')
    else
    disp('reject H0(ep1)- big data(1)!')    
    end
end
   %%3
QXX=inv(A'*w*A);
QLL=A*QXX*A';
QVV=inv(w)-QLL;
%

for j=1:length(w)
    for i=1:length(w)
    if i==j
    c1(i,j)=1;
    else
    c1(i,j)=0;
    end
    end
end

for i=1:length(w)
    w1(i)=real(((c1(i,:))*((w))*(v))/(sqrt(((c1(i,:))*((w))*abs(QVV)*((w))*(c1(:,i)))))); 
end

N= norminv(1-(0.05/2),0,1);
 temp5=[];
   for j=1:length(w)
   if w1(1,j)>N | w1(1,j)<-(N)
 fprintf('The range data is %f  \n',j)
 temp5=[temp5 j];
   else
       disp('accept H0(ep1)!')
       end
   end
   for i=1:numel(w1)
   w2(1,i)=abs(w1(1,i));
   end
   mx2=max(w2)
mxx2=find(max(w2(1,:))==w2(1,:));

A(mxx2,:)=[];
dL(mxx2,:)=[];
w(mxx2,:)=[];
w(:,mxx2)=[];
w1(:,mxx2)=[];
w2(:,mxx2)=[];
c1(mxx2,:)=[];
c1(:,mxx2)=[];
%
ang_h(mxx2-length(horizontal_distance),:)=[];
dx1= inv(A'*w*A)*A'*w*(dL);
%
while norm(dx1) > 10^-6
    clear A
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2);
    ds1(i,1) = dis(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
end
for i = 1: numel(ang_h(:,1))
    n1 = ang_h(i,1);
    n2 = ang_h(i,2);
    n3 = ang_h(i,3);
    angle3(i,1) = azimuth(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2))-azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if angle3(i,1)<0
angle3(i,1) = angle3(i,1)+2*pi;
end
end
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    AZ(i,1) = azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if AZ(i,1)<0
AZ(i,1) = AZ(i,1)+2*pi;
end
end
moshahede1=[horizontal_distance(:,3);deg2rad(ang_h(:,4));deg2rad(az(:,3));9498.26000000000;78594.9055000000];
mohasebati1=[ds1;angle3;AZ;XY(1,1);XY(1,2)];
dL0=moshahede1-mohasebati1;
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2); 
    s1 = ds1(i,1);
    g1 = diff_dist(XY(n1,1),XY(n2,1),s1);
    g2 = diff_dist(XY(n1,2),XY(n2,2),s1);
    A(i,2*n1-1:2*n1) = [-g1 -g2];  
    A(i,2*n2-1:2*n2) = [+g1 +g2]; 
end
n = numel(A(:,1));
for i = 1: numel(ang_h(:,1))
    n1 = ang_h(i,1);
    n2 = ang_h(i,2);
    n3 = ang_h(i,3);
    g1 = diff_az_x(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g2 = diff_az_y(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g3 = -diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = -diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A(i+n,2*n1-1:2*n1) = [-(g1+g3) -(g2+g4)];  
    A(i+n,2*n2-1:2*n2) = [g3 g4]; 
    A(i+n,2*n3-1:2*n3) = [g1 g2];
end
n = numel(A(:,1));
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    g3 = diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A(i+n,2*n1-1:2*n1) = [-g3 -g4];  
    A(i+n,2*n2-1:2*n2) = [g3 g4]; 
end
n = numel(A(:,1));
A(n+1:n+2,1*2-1:1*2)= [1 0;0 1];
dx1= (A'*w*A)^-1*A'*w*(dL0);
   Tim=Tim+1 ;
for i=1:7
    XY(i,1) = XY(i,1) + dx1(2*i-1);   
    XY(i,2) = XY(i,2) + dx1(2*i); 
end    
end
%
v = A*dx1-(dL0);
 T1=(v'*w*v);
X12=chi2inv(0.05/2,(length(A)-14));
X122=chi2inv(1-(0.05/2),(length(A)-14));
if X12<=T1
    if T1<=X122
  disp('accept H0(ep1)- No big data(1)!')
    else
    disp('reject H0(ep1)- big data(1)!')    
    end
end
%%4
QXX=inv(A'*w*A);
QLL=A*QXX*A';
QVV=inv(w)-QLL;
%

for j=1:length(w)
    for i=1:length(w)
    if i==j
    c1(i,j)=1;
    else
    c1(i,j)=0;
    end
    end
end

for i=1:length(w)
    w1(i)=real(((c1(i,:))*((w))*(v))/(sqrt(((c1(i,:))*((w))*abs(QVV)*((w))*(c1(:,i)))))); 
end

N= norminv(1-(0.05/2),0,1);
 temp5=[];
   for j=1:length(w)
   if w1(1,j)>N | w1(1,j)<-(N)
 fprintf('The range data is %f  \n',j)
 temp5=[temp5 j];
   else
       disp('accept H0(ep1)!')
       end
   end
   for i=1:numel(w1)
   w2(1,i)=abs(w1(1,i));
   end
   mx3=max(w2)
mxx3=find(max(w2(1,:))==w2(1,:));

A(mxx3,:)=[];
dL(mxx3,:)=[];
w(mxx3,:)=[];
w(:,mxx3)=[];

ang_h(mxx3-length(horizontal_distance),:)=[];
dx1= inv(A'*w*A)*A'*w*(dL);
%
while norm(dx1) > 10^-6
    clear A
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2);
    ds1(i,1) = dis(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
end
for i = 1: numel(ang_h(:,1))
    n1 = ang_h(i,1);
    n2 = ang_h(i,2);
    n3 = ang_h(i,3);
    angle4(i,1) = azimuth(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2))-azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if angle4(i,1)<0
angle4(i,1) = angle4(i,1)+2*pi;
end
end
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    AZ(i,1) = azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if AZ(i,1)<0
AZ(i,1) = AZ(i,1)+2*pi;
end
end
moshahede1=[horizontal_distance(:,3);deg2rad(ang_h(:,4));deg2rad(az(:,3));9498.26000000000;78594.9055000000];
mohasebati1=[ds1;angle4;AZ;XY(1,1);XY(1,2)];
dL0=moshahede1-mohasebati1;
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2); 
    s1 = ds1(i,1);
    g1 = diff_dist(XY(n1,1),XY(n2,1),s1);
    g2 = diff_dist(XY(n1,2),XY(n2,2),s1);
    A(i,2*n1-1:2*n1) = [-g1 -g2];  
    A(i,2*n2-1:2*n2) = [+g1 +g2]; 
end
n = numel(A(:,1));
for i = 1: numel(ang_h(:,1))
    n1 = ang_h(i,1);
    n2 = ang_h(i,2);
    n3 = ang_h(i,3);
    g1 = diff_az_x(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g2 = diff_az_y(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g3 = -diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = -diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A(i+n,2*n1-1:2*n1) = [-(g1+g3) -(g2+g4)];  
    A(i+n,2*n2-1:2*n2) = [g3 g4]; 
    A(i+n,2*n3-1:2*n3) = [g1 g2];
end
n = numel(A(:,1));
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    g3 = diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A(i+n,2*n1-1:2*n1) = [-g3 -g4];  
    A(i+n,2*n2-1:2*n2) = [g3 g4]; 
end
n = numel(A(:,1));
A(n+1:n+2,1*2-1:1*2)= [1 0;0 1];
dx1= (A'*w*A)^-1*A'*w*(dL0);
   Tim=Tim+1 ;
for i=1:7
    XY(i,1) = XY(i,1) + dx1(2*i-1);   
    XY(i,2) = XY(i,2) + dx1(2*i); 
end    
end
%
v = A*dx1-(dL0);
 T1=(v'*w*v);
X12=chi2inv(0.05/2,(length(A)-14));
X122=chi2inv(1-(0.05/2),(length(A)-14));
if X12<=T1
    if T1<=X122
  disp('accept H0(ep1)- No big data(1)!')
    else
    disp('reject H0(ep1)- big data(1)!')    
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%hazv data2
mxh=21;
A1(mxh,:)=[];
dL1(mxh,:)=[];
W(mxh,:)=[];
W(:,mxh)=[];
ang_z(mxh-length(horizontal_distance),:)=[];
dxz= inv(A1'*W*A1)*A1'*W*(dL1);
%
while norm(dxz) > 10^-6
    clear A1
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2);
    ds1(i,1) = dis(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
end
for i = 1: numel(ang_z(:,1))
    n1 = ang_z(i,1);
    n2 = ang_z(i,2);
    n3 = ang_z(i,3);
    anglez0(i,1) = azimuth(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2))-azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if anglez0(i,1)<0
anglez0(i,1) = anglez0(i,1)+2*pi;
end
end
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    AZ(i,1) = azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if AZ(i,1)<0
AZ(i,1) = AZ(i,1)+2*pi;
end
end
moshahede0=[horizontal_distance(:,3);deg2rad(ang_z(:,4));deg2rad(az(:,3));9498.26000000000;78594.9055000000];
mohasebati0=[ds1;anglez0;AZ;XY(1,1);XY(1,2)];
dL1=moshahede0-mohasebati0;
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2); 
    s1 = ds1(i,1);
    g1 = diff_dist(XY(n1,1),XY(n2,1),s1);
    g2 = diff_dist(XY(n1,2),XY(n2,2),s1);
    A1(i,2*n1-1:2*n1) = [-g1 -g2];  
    A1(i,2*n2-1:2*n2) = [+g1 +g2]; 
end
n = numel(A1(:,1));
for i = 1: numel(ang_z(:,1))
    n1 = ang_z(i,1);
    n2 = ang_z(i,2);
    n3 = ang_z(i,3);
    g1 = diff_az_x(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g2 = diff_az_y(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g3 = -diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = -diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A1(i+n,2*n1-1:2*n1) = [-(g1+g3) -(g2+g4)];  
    A1(i+n,2*n2-1:2*n2) = [g3 g4]; 
    A1(i+n,2*n3-1:2*n3) = [g1 g2];
end
n = numel(A1(:,1));
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    g3 = diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A1(i+n,2*n1-1:2*n1) = [-g3 -g4];  
    A1(i+n,2*n2-1:2*n2) = [g3 g4]; 
end
n = numel(A1(:,1));
A1(n+1:n+2,1*2-1:1*2)= [1 0;0 1];
dxz= (A1'*W*A1)^-1*A1'*W*(dL1);
   Tim=Tim+1 ;
for i=1:7
    XY(i,1) = XY(i,1) + dxz(2*i-1);   
    XY(i,2) = XY(i,2) + dxz(2*i); 
end    
end
%
v = A1*dxz-(dL1);
 T1=(v'*W*v);
X12=chi2inv(0.05/2,(length(A1)-14));
X122=chi2inv(1-(0.05/2),(length(A1)-14));
if X12<=T1
    if T1<=X122
  disp('accept H0(ep1)- No big data(1)!')
    else
    disp('reject H0(ep1)- big data(1)!')    
    end
end
%%2
mxh0=19;
A1(mxh0,:)=[];
dL1(mxh0,:)=[];
W(mxh0,:)=[];
W(:,mxh0)=[];
ang_z(mxh0-length(horizontal_distance),:)=[];
dxz= inv(A1'*W*A1)*A1'*W*(dL1);
%
while norm(dxz) > 10^-6
    clear A1
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2);
    ds1(i,1) = dis(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
end
for i = 1: numel(ang_z(:,1))
    n1 = ang_z(i,1);
    n2 = ang_z(i,2);
    n3 = ang_z(i,3);
    anglez1(i,1) = azimuth(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2))-azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if anglez1(i,1)<0
anglez1(i,1) = anglez1(i,1)+2*pi;
end
end
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    AZ(i,1) = azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if AZ(i,1)<0
AZ(i,1) = AZ(i,1)+2*pi;
end
end
moshahede0=[horizontal_distance(:,3);deg2rad(ang_z(:,4));deg2rad(az(:,3));9498.26000000000;78594.9055000000];
mohasebati0=[ds1;anglez1;AZ;XY(1,1);XY(1,2)];
dL1=moshahede0-mohasebati0;
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2); 
    s1 = ds1(i,1);
    g1 = diff_dist(XY(n1,1),XY(n2,1),s1);
    g2 = diff_dist(XY(n1,2),XY(n2,2),s1);
    A1(i,2*n1-1:2*n1) = [-g1 -g2];  
    A1(i,2*n2-1:2*n2) = [+g1 +g2]; 
end
n = numel(A1(:,1));
for i = 1: numel(ang_z(:,1))
    n1 = ang_z(i,1);
    n2 = ang_z(i,2);
    n3 = ang_z(i,3);
    g1 = diff_az_x(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g2 = diff_az_y(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g3 = -diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = -diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A1(i+n,2*n1-1:2*n1) = [-(g1+g3) -(g2+g4)];  
    A1(i+n,2*n2-1:2*n2) = [g3 g4]; 
    A1(i+n,2*n3-1:2*n3) = [g1 g2];
end
n = numel(A1(:,1));
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    g3 = diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A1(i+n,2*n1-1:2*n1) = [-g3 -g4];  
    A1(i+n,2*n2-1:2*n2) = [g3 g4]; 
end
n = numel(A1(:,1));
A1(n+1:n+2,1*2-1:1*2)= [1 0;0 1];
dxz= (A1'*W*A1)^-1*A1'*W*(dL1);
   Tim=Tim+1 ;
for i=1:7
    XY(i,1) = XY(i,1) + dxz(2*i-1);   
    XY(i,2) = XY(i,2) + dxz(2*i); 
end    
end
%
v = A1*dxz-(dL1);
 T1=(v'*W*v);
X12=chi2inv(0.05/2,(length(A1)-14));
X122=chi2inv(1-(0.05/2),(length(A1)-14));
if X12<=T1
    if T1<=X122
  disp('accept H0(ep1)- No big data(1)!')
    else
    disp('reject H0(ep1)- big data(1)!')    
    end
end
%3
mxh1=13;
A1(mxh1,:)=[];
dL1(mxh1,:)=[];
W(mxh1,:)=[];
W(:,mxh1)=[];
ang_z(mxh1-length(horizontal_distance),:)=[];
dxz= inv(A1'*W*A1)*A1'*W*(dL1);
%
while norm(dxz) > 10^-6
    clear A1
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2);
    ds1(i,1) = dis(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
end
for i = 1: numel(ang_z(:,1))
    n1 = ang_z(i,1);
    n2 = ang_z(i,2);
    n3 = ang_z(i,3);
    anglez2(i,1) = azimuth(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2))-azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if anglez2(i,1)<0
anglez2(i,1) = anglez2(i,1)+2*pi;
end
end
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    AZ(i,1) = azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if AZ(i,1)<0
AZ(i,1) = AZ(i,1)+2*pi;
end
end
moshahede0=[horizontal_distance(:,3);deg2rad(ang_z(:,4));deg2rad(az(:,3));9498.26000000000;78594.9055000000];
mohasebati0=[ds1;anglez2;AZ;XY(1,1);XY(1,2)];
dL1=moshahede0-mohasebati0;
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2); 
    s1 = ds1(i,1);
    g1 = diff_dist(XY(n1,1),XY(n2,1),s1);
    g2 = diff_dist(XY(n1,2),XY(n2,2),s1);
    A1(i,2*n1-1:2*n1) = [-g1 -g2];  
    A1(i,2*n2-1:2*n2) = [+g1 +g2]; 
end
n = numel(A1(:,1));
for i = 1: numel(ang_z(:,1))
    n1 = ang_z(i,1);
    n2 = ang_z(i,2);
    n3 = ang_z(i,3);
    g1 = diff_az_x(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g2 = diff_az_y(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g3 = -diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = -diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A1(i+n,2*n1-1:2*n1) = [-(g1+g3) -(g2+g4)];  
    A1(i+n,2*n2-1:2*n2) = [g3 g4]; 
    A1(i+n,2*n3-1:2*n3) = [g1 g2];
end
n = numel(A1(:,1));
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    g3 = diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A1(i+n,2*n1-1:2*n1) = [-g3 -g4];  
    A1(i+n,2*n2-1:2*n2) = [g3 g4]; 
end
n = numel(A1(:,1));
A1(n+1:n+2,1*2-1:1*2)= [1 0;0 1];
dxz= (A1'*W*A1)^-1*A1'*W*(dL1);
   Tim=Tim+1 ;
for i=1:7
    XY(i,1) = XY(i,1) + dxz(2*i-1);   
    XY(i,2) = XY(i,2) + dxz(2*i); 
end    
end
%
v = A1*dxz-(dL1);
 T1=(v'*W*v);
X12=chi2inv(0.05/2,(length(A1)-14));
X122=chi2inv(1-(0.05/2),(length(A1)-14));
if X12<=T1
    if T1<=X122
  disp('accept H0(ep1)- No big data(1)!')
    else
    disp('reject H0(ep1)- big data(1)!')    
    end
end
%%4
mxh2=18;
A1(mxh2,:)=[];
dL1(mxh2,:)=[];
W(mxh2,:)=[];
W(:,mxh2)=[];
ang_z(mxh2-length(horizontal_distance),:)=[];
dxz= inv(A1'*W*A1)*A1'*W*(dL1);
%
while norm(dxz) > 10^-6
    clear A1
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2);
    ds1(i,1) = dis(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
end
for i = 1: numel(ang_z(:,1))
    n1 = ang_z(i,1);
    n2 = ang_z(i,2);
    n3 = ang_z(i,3);
    anglez3(i,1) = azimuth(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2))-azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if anglez3(i,1)<0
anglez3(i,1) = anglez3(i,1)+2*pi;
end
end
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    AZ(i,1) = azimuth(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));    
if AZ(i,1)<0
AZ(i,1) = AZ(i,1)+2*pi;
end
end
moshahede0=[horizontal_distance(:,3);deg2rad(ang_z(:,4));deg2rad(az(:,3));9498.26000000000;78594.9055000000];
mohasebati0=[ds1;anglez3;AZ;XY(1,1);XY(1,2)];
dL1=moshahede0-mohasebati0;
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2); 
    s1 = ds1(i,1);
    g1 = diff_dist(XY(n1,1),XY(n2,1),s1);
    g2 = diff_dist(XY(n1,2),XY(n2,2),s1);
    A1(i,2*n1-1:2*n1) = [-g1 -g2];  
    A1(i,2*n2-1:2*n2) = [+g1 +g2]; 
end
n = numel(A1(:,1));
for i = 1: numel(ang_z(:,1))
    n1 = ang_z(i,1);
    n2 = ang_z(i,2);
    n3 = ang_z(i,3);
    g1 = diff_az_x(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g2 = diff_az_y(XY(n1,1),XY(n3,1),XY(n1,2),XY(n3,2));
    g3 = -diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = -diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A1(i+n,2*n1-1:2*n1) = [-(g1+g3) -(g2+g4)];  
    A1(i+n,2*n2-1:2*n2) = [g3 g4]; 
    A1(i+n,2*n3-1:2*n3) = [g1 g2];
end
n = numel(A1(:,1));
for i = 1: numel(az(:,1))
    n1 = az(i,1);
    n2 = az(i,2);
    g3 = diff_az_x(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    g4 = diff_az_y(XY(n1,1),XY(n2,1),XY(n1,2),XY(n2,2));
    A1(i+n,2*n1-1:2*n1) = [-g3 -g4];  
    A1(i+n,2*n2-1:2*n2) = [g3 g4]; 
end
n = numel(A1(:,1));
A1(n+1:n+2,1*2-1:1*2)= [1 0;0 1];
dxz= (A1'*W*A1)^-1*A1'*W*(dL1);
   Tim=Tim+1 ;
for i=1:7
    XY(i,1) = XY(i,1) + dxz(2*i-1);   
    XY(i,2) = XY(i,2) + dxz(2*i); 
end    
end
%
v = A1*dxz-(dL1);
 T1=(v'*W*v);
X12=chi2inv(0.05/2,(length(A1)-14));
X122=chi2inv(1-(0.05/2),(length(A1)-14));
if X12<=T1
    if T1<=X122
  disp('accept H0(ep1)- No big data(1)!')
    else
    disp('reject H0(ep1)- big data(1)!')    
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Meyar haye koli deghate shabake malum
F_norm=norm(QXX);
F_trace=trace(QXX);
F_det=det(QXX);
ValueOfEigen=eig(QXX);
F_Eigen=max(ValueOfEigen);
F_S=max(ValueOfEigen)-min(ValueOfEigen);  %%yeknavakhti deghat
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%beyzi khata
   %motlagh
v = A*dx1-(dL0);
   n=length(A);
   u=14;
d2=(v'*w*v)/(n-u);
   cd2=d2*inv(A'*w*A);

sig=diag(cd2);
sx10=sig(1,1);
sy10=sig(2,1);
sxy10=cd2(1,2);

sx20=sig(3,1);
sy20=sig(4,1);
sxy20=cd2(3,4);

sx30=sig(5,1);
sy30=sig(6,1);
sxy30=cd2(5,6);

sx40=sig(7,1);
sy40=sig(8,1);
sxy40=cd2(7,8);

sx50=sig(9,1);
sy50=sig(10,1);
sxy50=cd2(9,10);
   
 sx60=sig(11,1);
sy60=sig(12,1);
sxy60=cd2(11,12);

sx70=sig(13,1);
sy70=sig(14,1);
sxy70=cd2(13,14);

a=1;
b10=-(sx10+sy10);
c10=(sx10*sy10)-(sxy10)^2;

b20=-(sx20+sy20);
c20=(sx20*sy20)-(sxy20)^2;

b30=-(sx30+sy30);
c30=(sx30*sy30)-(sxy30)^2

b40=-(sx40+sy40);
c40=(sx40*sy40)-(sxy40)^2

b50=-(sx50+sy50);
c50=(sx50*sy50)-(sxy50)^2


b60=-(sx60+sy60);
c60=(sx60*sy60)-(sxy60)^2;

b70=-(sx70+sy70);
c70=(sx70*sy70)-(sxy70)^2;

syms landa
t1=a*landa^2+b10*landa+c10;
t2=a*landa^2+b20*landa+c20;
t3=a*landa^2+b30*landa+c30;
t4=a*landa^2+b40*landa+c40;
t5=a*landa^2+b50*landa+c50;
t6=a*landa^2+b60*landa+c60;
t7=a*landa^2+b70*landa+c70;

u1=solve(t1);
a1=sqrt(double(max(abs(u1))));
b1=sqrt(double(min(abs(u1))));
teta1=180-rad2deg(atan2(2*sxy10,(sx10-sy10)))/2;

u2=solve(t2);
a2=sqrt(double(max(abs(u2))));
b2=sqrt(double(min(abs(u2))));
teta2=180-rad2deg(atan2(2*sxy20,(sx20-sy20)))/2;

u3=solve(t3);
a3=sqrt(double(max(abs(u3))));
b3=sqrt(double(min(abs(u3))));
teta3=180-rad2deg(atan2(2*sxy30,(sx30-sy30)))/2;

u4=solve(t4);
a4=sqrt(double(max(abs(u4))));
b4=sqrt(double(min(abs(u4))));
teta4=180-rad2deg(atan2(2*sxy40,(sx40-sy40)))/2;

u5=solve(t5);
a5=sqrt(double(max(abs(u5))));
b5=sqrt(double(min(abs(u5))));
teta5=180-rad2deg(atan2(2*sxy50,(sx50-sy50)))/2;

u6=solve(t6);
a6=sqrt(double(max(abs(u6))));
b6=sqrt(double(min(abs(u6))));
teta6=180-rad2deg(atan2(2*sxy60,(sx60-sy60)))/2;

u7=solve(t7);
a7=sqrt(double(max(abs(u7))));
b7=sqrt(double(min(abs(u7))));
teta7=180-rad2deg(atan2(2*sxy70,(sx70-sy70)))/2;
%%plot motlagh
X2=[XY(1,1);XY(1,2);XY(2,1);XY(2,2);XY(3,1);XY(3,2);XY(4,1);XY(4,2);XY(5,1);XY(5,2);XY(6,1);XY(6,2);XY(7,1);XY(7,2)];
k=sqrt(chi2inv(0.95,2));


M10=[X2(1,1) X2(2,1);X2(3,1) X2(4,1);X2(5,1) X2(6,1);X2(7,1) X2(8,1);X2(9,1) X2(10,1);X2(11,1) X2(12,1);X2(13,1) X2(14,1)];
Q10=[0 1 1 1 1 1 1;1 0 0 0 1 0 0;1 0 0 0 1 0 0;1 0 0 0 1 0 0;1 1 1 1 0 1 1;1 0 0 0 1 0 0;1 0 0 0 1 0 0];

figure(1)
gplot(Q10,M10,'-o')
hold on
k=sqrt(chi2inv(0.95,2));
%motlagh
ellipse(a1*k*10^4,b1*k*10^5,teta1,X2(1,1),X2(2,1),'m')
ellipse(a2*k*10^4,b2*k*10^4,teta2,X2(3,1),X2(4,1),'k')
ellipse(k*a3*10^4,b3*k*10^4,teta3,X2(5,1),X2(6,1),'r')
ellipse(a4*k*10^4,b4*k*10^4,teta4,X2(7,1),X2(8,1),'g')
ellipse(a5*k*10^4,b5*k*10^4,teta5,X2(9,1),X2(10,1),'c')
ellipse(a6*k*10^4,b6*k*10^4,teta6,X2(11,1),X2(12,1),'r')
ellipse(a7*k*10^4,b7*k*10^4,teta7,X2(13,1),X2(14,1),'y')
xlabel('mehvar X')
ylabel('mehvar Y')
title('beyzi khataye motlagh noghte ')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%555555
%%khataye nesbi
%noghte 2,3
AS=[-1,0,1,0;0,-1,0,1];
sig12=[cd2(1,1),cd2(1,2),cd2(1,3),cd2(1,4);cd2(2,1),cd2(2,2),cd2(2,3),cd2(2,4);cd2(3,1),cd2(3,2),cd2(3,3),cd2(3,4);cd2(4,1),cd2(4,2),cd2(4,3),cd2(4,4)];
sigdlt12=AS*sig12*AS';

sig13=[cd2(1,1),cd2(1,2),cd2(1,5),cd2(1,6);cd2(2,1),cd2(2,2),cd2(2,5),cd2(2,6);cd2(5,1),cd2(5,2),cd2(5,5),cd2(5,6);cd2(6,1),cd2(6,2),cd2(6,5),cd2(6,6)];
sigdlt13=AS*sig13*AS';

sig14=[cd2(1,1),cd2(1,2),cd2(1,7),cd2(1,8);cd2(2,1),cd2(2,2),cd2(2,7),cd2(2,8);cd2(7,1),cd2(7,2),cd2(7,7),cd2(7,8);cd2(8,1),cd2(8,2),cd2(8,7),cd2(8,8)];
sigdlt14=AS*sig14*AS';

sig15=[cd2(1,1),cd2(1,2),cd2(1,9),cd2(1,10);cd2(2,1),cd2(2,2),cd2(2,9),cd2(2,10);cd2(9,1),cd2(9,2),cd2(9,9),cd2(9,10);cd2(10,1),cd2(10,2),cd2(10,9),cd2(10,10)];
sigdlt15=AS*sig15*AS';

sig16=[cd2(1,1),cd2(1,2),cd2(1,11),cd2(1,12);cd2(2,1),cd2(2,2),cd2(2,11),cd2(2,12);cd2(11,1),cd2(11,2),cd2(11,11),cd2(11,12);cd2(12,1),cd2(12,2),cd2(12,11),cd2(12,12)];
sigdlt16=AS*sig16*AS';

sig17=[cd2(1,1),cd2(1,2),cd2(1,13),cd2(1,14);cd2(2,1),cd2(2,2),cd2(2,13),cd2(2,14);cd2(13,1),cd2(13,2),cd2(13,13),cd2(13,14);cd2(14,1),cd2(14,2),cd2(14,13),cd2(14,13)];
sigdlt17=AS*sig17*AS';

sig25=[cd2(3,3),cd2(3,4),cd2(3,9),cd2(3,10);cd2(4,3),cd2(4,4),cd2(4,9),cd2(4,10);cd2(9,3),cd2(9,4),cd2(9,9),cd2(9,10);cd2(10,3),cd2(10,4),cd2(10,9),cd2(10,10)];
sigdlt25=AS*sig25*AS';

sig35=[cd2(5,5),cd2(5,6),cd2(5,9),cd2(5,10);cd2(6,5),cd2(6,6),cd2(6,9),cd2(6,10);cd2(9,5),cd2(9,6),cd2(9,9),cd2(9,10);cd2(10,5),cd2(10,6),cd2(10,9),cd2(10,10)];
sigdlt35=AS*sig35*AS';

sig45=[cd2(7,7),cd2(7,8),cd2(7,9),cd2(7,10);cd2(8,7),cd2(8,8),cd2(8,9),cd2(8,10);cd2(9,7),cd2(9,8),cd2(9,9),cd2(9,10);cd2(10,7),cd2(10,8),cd2(10,9),cd2(10,10)];
sigdlt45=AS*sig45*AS';

sig75=[cd2(9,9),cd2(9,10),cd2(9,13),cd2(9,14);cd2(10,9),cd2(10,10),cd2(10,13),cd2(10,14);cd2(13,9),cd2(14,10),cd2(13,13),cd2(13,14);cd2(14,9),cd2(14,10),cd2(14,13),cd2(14,14)];
sigdlt75=AS*sig75*AS';

sig65=[cd2(9,9),cd2(9,10),cd2(9,11),cd2(9,12);cd2(10,9),cd2(10,10),cd2(10,11),cd2(10,12);cd2(11,9),cd2(11,10),cd2(11,11),cd2(11,12);cd2(12,9),cd2(12,10),cd2(12,11),cd2(12,12)];
sigdlt65=AS*sig65*AS';


sdx12=sigdlt12(1,1);
sdy12=sigdlt12(2,2);
sdxy12=sigdlt12(1,2);

sdx13=sigdlt13(1,1);
sdy13=sigdlt13(2,2);
sdxy13=sigdlt13(1,2);

sdx14=sigdlt14(1,1);
sdy14=sigdlt14(2,2);
sdxy14=sigdlt14(1,2);

sdx15=sigdlt15(1,1);
sdy15=sigdlt15(2,2);
sdxy15=sigdlt15(1,2);

sdx16=sigdlt16(1,1);
sdy16=sigdlt16(2,2);
sdxy16=sigdlt16(1,2);

sdx17=sigdlt17(1,1);
sdy17=sigdlt17(2,2);
sdxy17=sigdlt17(1,2);

sdx25=sigdlt25(1,1);
sdy25=sigdlt25(2,2);
sdxy25=sigdlt25(1,2);

sdx35=sigdlt35(1,1);
sdy35=sigdlt35(2,2);
sdxy35=sigdlt35(1,2);

sdx45=sigdlt45(1,1);
sdy45=sigdlt45(2,2);
sdxy45=sigdlt45(1,2);

sdx75=sigdlt75(1,1);
sdy75=sigdlt75(2,2);
sdxy75=sigdlt75(1,2);

sdx65=sigdlt65(1,1);
sdy65=sigdlt65(2,2);
sdxy65=sigdlt65(1,2);



a=1;
db12=-1*(sdx12+sdy12);
c12=(sdx12*sdy12)-(sdxy12)^2;

db13=-1*(sdx13+sdy13);
c13=(sdx13*sdy13)-(sdxy13)^2;

db14=-1*(sdx14+sdy14);
c14=(sdx14*sdy14)-(sdxy14)^2;

db15=-1*(sdx15+sdy15);
c15=(sdx15*sdy15)-(sdxy15)^2;

db16=-1*(sdx16+sdy16);
c16=(sdx16*sdy16)-(sdxy16)^2;

db17=-1*(sdx17+sdy17);
c17=(sdx17*sdy17)-(sdxy17)^2;

db25=-1*(sdx25+sdy25);
c25=(sdx25*sdy25)-(sdxy25)^2;

db35=-1*(sdx35+sdy35);
c35=(sdx35*sdy35)-(sdxy35)^2;

db75=-1*(sdx75+sdy75);
c75=(sdx75*sdy75)-(sdxy75)^2;

db45=-1*(sdx45+sdy45);
c45=(sdx45*sdy45)-(sdxy45)^2;

db65=-1*(sdx65+sdy65);
c65=(sdx65*sdy65)-(sdxy65)^2;


syms landa1
k1=a*(landa1)^2+db12*(landa1)+c12;
k11=a*(landa1)^2+db13*(landa1)+c13;
k2=a*(landa1)^2+db14*(landa1)+c14;
k3=a*(landa1)^2+db15*(landa1)+c15;
k4=a*(landa1)^2+db16*(landa1)+c16;
k5=a*(landa1)^2+db17*(landa1)+c17;
k6=a*(landa1)^2+db25*(landa1)+c25;
k7=a*(landa1)^2+db35*(landa1)+c35;
k8=a*(landa1)^2+db45*(landa1)+c45;
k9=a*(landa1)^2+db65*(landa1)+c65;
k10=a*(landa1)^2+db75*(landa1)+c75;


f1=solve(k1);
a12=sqrt(double(max(abs(f1))));
b12=sqrt(double(min(abs(f1))));
teta12=rad2deg(atan2(2*sdxy13,(sdx12-sdy12)))/2;

f11=solve(k11);
a13=sqrt(double(max(abs(f11))));
b13=sqrt(double(min(abs(f11))));
teta13=rad2deg(atan2(2*sdxy13,(sdx13-sdy13)))/2;

f2=solve(k2);
a14=sqrt(double(max(abs(f2))));
b14=sqrt(double(min(abs(f2))));
teta14=rad2deg(atan2(2*sdxy14,(sdx14-sdy14)))/2;

f3=solve(k3);
a15=sqrt(double(max(abs(f3))));
b15=sqrt(double(min(abs(f3))));
teta15=atan2(2*sdxy15,(sdx15-sdy15))/2;

f4=solve(k4);
a16=sqrt(double(max(abs(f4))));
b16=sqrt(double(min(abs(f4))));
teta16=atan2(2*sdxy16,(sdx16-sdy16))/2;

f5=solve(k5);
a17=sqrt(double(max(abs(f5))));
b17=sqrt(double(min(abs(f5))));
teta17=atan2(2*sdxy17,(sdx17-sdy17))/2;

f6=solve(k6);
a25=sqrt(double(max(abs(f6))));
b25=sqrt(double(min(abs(f6))));
teta25=atan2(2*sdxy25,(sdx25-sdy25))/2;

f7=solve(k7);
a35=sqrt(double(max(abs(f7))));
b35=sqrt(double(min(abs(f7))));
teta35=atan2(2*sdxy35,(sdx35-sdy35))/2;

f8=solve(k8);
a45=sqrt(double(max(abs(f8))));
b45=sqrt(double(min(abs(f8))));
teta45=atan2(2*sdxy45,(sdx45-sdy45))/2;

f9=solve(k9);
a65=sqrt(double(max(abs(f9))));
b65=sqrt(double(min(abs(f9))));
teta65=atan2(2*sdxy65,(sdx65-sdy65))/2;

f10=solve(k10);
a75=sqrt(double(max(abs(f10))));
b75=sqrt(double(min(abs(f10))));
teta75=atan2(2*sdxy75,(sdx75-sdy75))/2;

X2=[XY(1,1);XY(1,2);XY(2,1);XY(2,2);XY(3,1);XY(3,2);XY(4,1);XY(4,2);XY(5,1);XY(5,2);XY(6,1);XY(6,2);XY(7,1);XY(7,2)];

x12=(X2(1,1)+X2(3,1))/2;
y12=(X2(2,1)+X2(4,1))/2;

x13=(X2(1,1)+X2(5,1))/2;
y13=(X2(2,1)+X2(6,1))/2;

x14=(X2(1,1)+X2(7,1))/2;
y14=(X2(2,1)+X2(8,1))/2;

x15=(X2(1,1)+X2(9,1))/2;
y15=(X2(2,1)+X2(10,1))/2;

x16=(X2(1,1)+X2(11,1))/2;
y16=(X2(2,1)+X2(12,1))/2;

x17=(X2(1,1)+X2(13,1))/2;
y17=(X2(2,1)+X2(14,1))/2;

x25=(X2(3,1)+X2(9,1))/2;
y25=(X2(4,1)+X2(10,1))/2;

x35=(X2(5,1)+X2(9,1))/2;
y35=(X2(6,1)+X2(10,1))/2;

x45=(X2(7,1)+X2(9,1))/2;
y45=(X2(8,1)+X2(10,1))/2;

x65=(X2(9,1)+X2(11,1))/2;
y65=(X2(10,1)+X2(12,1))/2;

x75=(X2(9,1)+X2(13,1))/2;
y75=(X2(10,1)+X2(14,1))/2;

%graph

M20=[X2(1,1) X2(2,1);X2(3,1) X2(4,1);X2(5,1) X2(6,1);X2(7,1) X2(8,1);X2(9,1) X2(10,1);X2(11,1) X2(12,1);X2(13,1) X2(14,1)];
Q20=[0 1 1 1 1 1 1;1 0 0 0 1 0 0;1 0 0 0 1 0 0;1 0 0 0 1 0 0;1 1 1 1 0 1 1;1 0 0 0 1 0 0;1 0 0 0 1 0 0];

figure(2)
gplot(Q20,M20,'-o')
hold on
k=sqrt(chi2inv(0.95,2));


%nesbi
ellipse(k*a12*10^4,b12*k*10^4,teta12,x12,y12,'b')
ellipse(k*a13*10^4,b13*k*10^4,teta13,x13,y13,'r')
ellipse(k*a14*10^4,b14*k*10^4,teta14,x14,y14,'k')
ellipse(k*a15*10^4,b15*k*10^4,teta15,x15,y15,'m')
ellipse(k*a16*10^4,b16*k*10^4,teta16,x16,y16,'g')
ellipse(k*a17*10^4,b17*k*10^4,teta17,x17,y17,'y')
ellipse(k*a25*10^4,b25*k*10^4,teta25,x25,y25,'b')
ellipse(k*a45*10^4,b45*k*10^4,teta45,x45,y45,'g')
 ellipse(k*a35*10^4,b35*k*10^4,teta35,x35,y35,'c')
 ellipse(k*a65*10^4,b65*k*10^4,teta65,x65,y65,'r')
 ellipse(k*a75*10^4,b75*k*10^4,teta75,x75,y75,'y')
xlabel('Easthing')
ylabel('Northing')
title(' graph beyzi khataye nesbi')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%project 3
R=eye(length(A(:,1)),length(A(:,1)))-(A*inv(A'*w*A)*A'*w);
nf=diag(abs(R));
minn=min(nf)
tool(1:12)=nf(1:12);
zavie(1:13)=nf(13:25);
figure(3)
plot(tool,'*')
figure(4)
plot(zavie,'*')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%internal reliability_MDB
Qe=R*inv(w);            %malum
lambda=((0.2-0.2464)/-0.0538)+7;

for j=1:length(Qe)
    for i=1:length(Qe)
    if i==j
    ci(i,j)=1;
    else
    ci(i,j)=0;
    end
    end
end

for i=1:length(Qe)
lMDB(i,1)=sqrt(abs(lambda/(ci(i,:)*w*Qe*w*ci(:,i))));
end
for i=1:length(Qe)
labla=inv(A'*w*A)*A'*w*(ci(i,:))'*lMDB';
end
num_x=[];
for i=1:14
    num_x(i,1)=i;
end
for i=1:26
norm_labla(1,1:26)=norm(labla(:,i));
end
num_L=[];
for i=1:26
    num_L(i,1)=i;
end

figure(5)
% gplot(Q20,M20,'-o')
% 
subplot(9,3,1)
plot(num_x,labla(:,1),'o')
subplot(9,3,2)
plot(num_x,labla(:,2),'*')
subplot(9,3,3)
plot(num_x,labla(:,3),'o')
subplot(9,3,4)
plot(num_x,labla(:,4),'o')
subplot(9,3,5)
plot(num_x,labla(:,5),'o')
subplot(9,3,6)
plot(num_x,labla(:,6),'o')
subplot(9,3,7)
plot(num_x,labla(:,7),'o')
subplot(9,3,8)
plot(num_x,labla(:,8),'o')
subplot(9,3,9)
plot(num_x,labla(:,9),'o')
subplot(9,3,10)
plot(num_x,labla(:,10),'o')
subplot(9,3,11)
plot(num_x,labla(:,11),'o')
subplot(9,3,12)
plot(num_x,labla(:,12),'o')
subplot(9,3,13)
plot(num_x,labla(:,13),'o')
subplot(9,3,14)
plot(num_x,labla(:,14),'o')
subplot(9,3,15)
plot(num_x,labla(:,15),'o')
subplot(9,3,16)
plot(num_x,labla(:,16),'o')

subplot(9,3,17)
plot(num_x,labla(:,17),'o')
subplot(9,3,18)
plot(num_x,labla(:,18),'o')

subplot(9,3,19)
plot(num_x,labla(:,19),'o')
subplot(9,3,20)
plot(num_x,labla(:,20),'o')

subplot(9,3,21)
plot(num_x,labla(:,21),'o')
subplot(9,3,22)
plot(num_x,labla(:,22),'o')
subplot(9,3,23)
plot(num_x,labla(:,23),'o')
subplot(9,3,24)
plot(num_x,labla(:,24),'o')
subplot(9,3,25)
plot(num_x,labla(:,25),'o')
subplot(9,3,26)
plot(num_x,labla(:,26),'o')
subplot(9,3,27)

plot(num_L,norm_labla,'x')




%% DATUM

clear all
close all
clc
format long 
az=dlmread('D:\D\lesson\term 6\jheodetic\project\4_6024070702158580249\project_G5_materials\ep1\Azimuth.txt');
h_angle=dlmread('D:\D\lesson\term 6\jheodetic\project\4_6024070702158580249\project_G5_materials\ep1\Horizintal_Angles.txt');
horizontal_distance=dlmread('D:\D\lesson\term 6\jheodetic\project\4_6024070702158580249\project_G5_materials\ep1\horizontal_distance.txt');

XY=[9498.2600 78594.9055;1.036757102703296*10^4 7.591320896809051*10^4;0.930041772335932*10^4 7.530673940701323*10^4;7.115104587912532*10^3 7.572360284452353*10^4;0.720664412517403*10^4 7.890786685116652e+04;6.633265995427694*10^3 7.670152330922795*10^4;8.401875515180878*10^3 7.660780757881723*10^4];

H=[1,0,-XY(1,2);0,1,XY(1,1);1,0,-XY(2,2);0,1,XY(2,1);1,0,-XY(3,2);0,1,XY(3,1);1,0,-XY(4,2);0,1,XY(4,1);1,0,-XY(5,2);0,1,XY(5,1);1,0,-XY(6,2);0,1,XY(6,1);1,0,-XY(7,2);0,1,XY(7,1)];
D2=[1,0,0,0,0,0,0,0,0,0,0,0,0,0;0,1,0,0,0,0,0,0,0,0,0,0,0,0;-(XY(2,2)-XY(1,2)),XY(2,1)-XY(1,1),XY(2,2)-XY(1,2),-(XY(2,1)-XY(1,1)),0,0,0,0,0,0,0,0,0,0];

S=eye(14,14)-H*inv(D2*H)*D2;

X=[XY(1,1);XY(1,2);XY(2,1);XY(2,2);XY(3,1);XY(3,2);XY(4,1);XY(4,2);XY(5,1);XY(5,2);XY(6,1);XY(6,2);XY(7,1);XY(7,2)];
X_Inner=S*X;
for i=1:length(X_Inner)/2;
XS(i,1)=X_Inner(2*i-1);
XS(i,2)=X_Inner(2*i);
end

dis=@(x1,x2,y1,y2) sqrt((x2-x1)^2+(y2-y1)^2);
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2);
    Ds1(i,1) = dis(XS(n1,1),XS(n2,1),XS(n1,2),XS(n2,2));    
end
L0=horizontal_distance(:,3);
L1=Ds1;
dLs=L0-L1;
deghat=0.005;
for i = 1:length (horizontal_distance)
ws(i,i) = 1/deghat^2;
end
diff_dist = @(f1,f2,s) -(f1 - f2)/s;
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2); 
    s1 = Ds1(i,1);
    gs1 = diff_dist(XS(n1,1),XS(n2,1),s1);
    gs2 = diff_dist(XS(n1,2),XS(n2,2),s1);
    As(i,2*n1-1:2*n1) = [-gs1 -gs2];  
    As(i,2*n2-1:2*n2) = [+gs1 +gs2]; 
end
% dxs = pinv(As'*ws*As)*As'*ws*(dLs);
    dxs=inv((As'*ws*As)+(H*H'))*(As'*ws*dLs);
for i=1:7
    XS(i,1) = XS(i,1) + dxs(2*i-1);   
    XS(i,2) = XS(i,2) + dxs(2*i); 
end
tim=1;
while norm(dxs) > 10^-6
    clear As
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2);
    Ds1(i,1) = dis(XS(n1,1),XS(n2,1),XS(n1,2),XS(n2,2));    
end

L0=horizontal_distance(:,3);
L1=Ds1;
dLs=L0-L1;
diff_dist = @(f1,f2,s) -(f1 - f2)/s;
for i = 1: numel(horizontal_distance(:,1))
    n1 = horizontal_distance(i,1);
    n2 = horizontal_distance(i,2); 
    s1 = Ds1(i,1);
    gs1 = diff_dist(XS(n1,1),XS(n2,1),s1);
    gs2 = diff_dist(XS(n1,2),XS(n2,2),s1);
    As(i,2*n1-1:2*n1) = [-gs1 -gs2];  
    As(i,2*n2-1:2*n2) = [+gs1 +gs2]; 
end
% dxs = pinv(As'*ws*As)*As'*ws*(dLs);
    dxs=inv((As'*ws*As)+(H*H'))*(As'*ws*dLs);

   tim=tim+1 ;
for i=1:7
    XS(i,1) = XS(i,1) + dxs(2*i-1);   
    XS(i,2) = XS(i,2) + dxs(2*i); 
end
end

QXXs=pinv(As'*ws*As);
vs=(As*dxs)-dLs;
 TS=(vs'*ws*vs);
X12=chi2inv(0.05/2,(length(As(:,1))-14+3));
X122=chi2inv(1-(0.05/2),(length(As(:,1))-14+3));
if X12<=TS
    if TS<=X122
  disp('accept H0(ep1)- No big data in DATUM(1)!')
    else
    disp('reject H0(ep1)- big data in DATUM(1)!')    
    end
end


  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%Meyar haye koli deghate shabake qoyud dakheli
F_norm1=norm(QXXs);
F_trace1=trace(QXXs);
F_det1=det(QXXs);
ValueOfEigen1=eig(QXXs);
F_Eigen1=max(ValueOfEigen1);
F_S1=max(ValueOfEigen1)-min(ValueOfEigen1);  %%yeknavakhti deghat
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%beyzi khata
   %motlagh
vs=(As*dxs)-dLs;
   n=length(As);
   u=14;
d2=(vs'*ws*vs)/(n-u+3);
   cd2=d2*pinv(As'*ws*As);

sig=diag(cd2);
sx10=sig(1,1);
sy10=sig(2,1);
sxy10=cd2(1,2);

sx20=sig(3,1);
sy20=sig(4,1);
sxy20=cd2(3,4);

sx30=sig(5,1);
sy30=sig(6,1);
sxy30=cd2(5,6);

sx40=sig(7,1);
sy40=sig(8,1);
sxy40=cd2(7,8);

sx50=sig(9,1);
sy50=sig(10,1);
sxy50=cd2(9,10);
   
 sx60=sig(11,1);
sy60=sig(12,1);
sxy60=cd2(11,12);

sx70=sig(13,1);
sy70=sig(14,1);
sxy70=cd2(13,14);

a=1;
b10=-(sx10+sy10);
c10=(sx10*sy10)-(sxy10)^2;

b20=-(sx20+sy20);
c20=(sx20*sy20)-(sxy20)^2;

b30=-(sx30+sy30);
c30=(sx30*sy30)-(sxy30)^2

b40=-(sx40+sy40);
c40=(sx40*sy40)-(sxy40)^2

b50=-(sx50+sy50);
c50=(sx50*sy50)-(sxy50)^2


b60=-(sx60+sy60);
c60=(sx60*sy60)-(sxy60)^2;

b70=-(sx70+sy70);
c70=(sx70*sy70)-(sxy70)^2;

syms landa
t1=a*landa^2+b10*landa+c10;
t2=a*landa^2+b20*landa+c20;
t3=a*landa^2+b30*landa+c30;
t4=a*landa^2+b40*landa+c40;
t5=a*landa^2+b50*landa+c50;
t6=a*landa^2+b60*landa+c60;
t7=a*landa^2+b70*landa+c70;

u1=solve(t1);
a1=sqrt(double(max(abs(u1))));
b1=sqrt(double(min(abs(u1))));
teta1=180-rad2deg(atan2(2*sxy10,(sx10-sy10)))/2;

u2=solve(t2);
a2=sqrt(double(max(abs(u2))));
b2=sqrt(double(min(abs(u2))));
teta2=180-rad2deg(atan2(2*sxy20,(sx20-sy20)))/2;

u3=solve(t3);
a3=sqrt(double(max(abs(u3))));
b3=sqrt(double(min(abs(u3))));
teta3=180-rad2deg(atan2(2*sxy30,(sx30-sy30)))/2;

u4=solve(t4);
a4=sqrt(double(max(abs(u4))));
b4=sqrt(double(min(abs(u4))));
teta4=180-rad2deg(atan2(2*sxy40,(sx40-sy40)))/2;

u5=solve(t5);
a5=sqrt(double(max(abs(u5))));
b5=sqrt(double(min(abs(u5))));
teta5=180-rad2deg(atan2(2*sxy50,(sx50-sy50)))/2;

u6=solve(t6);
a6=sqrt(double(max(abs(u6))));
b6=sqrt(double(min(abs(u6))));
teta6=180-rad2deg(atan2(2*sxy60,(sx60-sy60)))/2;

u7=solve(t7);
a7=sqrt(double(max(abs(u7))));
b7=sqrt(double(min(abs(u7))));
teta7=180-rad2deg(atan2(2*sxy70,(sx70-sy70)))/2;
%%plot motlagh
X2=[XY(1,1);XY(1,2);XY(2,1);XY(2,2);XY(3,1);XY(3,2);XY(4,1);XY(4,2);XY(5,1);XY(5,2);XY(6,1);XY(6,2);XY(7,1);XY(7,2)];
k=sqrt(chi2inv(0.95,2));


M10=[X2(1,1) X2(2,1);X2(3,1) X2(4,1);X2(5,1) X2(6,1);X2(7,1) X2(8,1);X2(9,1) X2(10,1);X2(11,1) X2(12,1);X2(13,1) X2(14,1)];
Q10=[0 1 1 1 1 1 1;1 0 0 0 1 0 0;1 0 0 0 1 0 0;1 0 0 0 1 0 0;1 1 1 1 0 1 1;1 0 0 0 1 0 0;1 0 0 0 1 0 0];

figure(1)
gplot(Q10,M10,'-o')
hold on
k=sqrt(chi2inv(0.95,2));
%motlagh
ellipse(a1*k*10^5,b1*k*10^5,teta1,X2(1,1),X2(2,1),'m')
ellipse(a2*k*10^4,b2*k*10^5,teta2,X2(3,1),X2(4,1),'k')
ellipse(k*a3*10^4,b3*k*10^5,teta3,X2(5,1),X2(6,1),'r')
ellipse(a4*k*10^4,b4*k*10^5,teta4,X2(7,1),X2(8,1),'g')
ellipse(a5*k*10^5,b5*k*10^5,teta5,X2(9,1),X2(10,1),'c')
ellipse(a6*k*10^4,b6*k*10^5,teta6,X2(11,1),X2(12,1),'r')
ellipse(a7*k*10^5,b7*k*10^5,teta7,X2(13,1),X2(14,1),'y')
xlabel('mehvar X')
ylabel('mehvar Y')
title('beyzi khataye motlagh noghte ')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%555555
%%khataye nesbi
%noghte 2,3
AS=[-1,0,1,0;0,-1,0,1];
sig12=[cd2(1,1),cd2(1,2),cd2(1,3),cd2(1,4);cd2(2,1),cd2(2,2),cd2(2,3),cd2(2,4);cd2(3,1),cd2(3,2),cd2(3,3),cd2(3,4);cd2(4,1),cd2(4,2),cd2(4,3),cd2(4,4)];
sigdlt12=AS*sig12*AS';

sig13=[cd2(1,1),cd2(1,2),cd2(1,5),cd2(1,6);cd2(2,1),cd2(2,2),cd2(2,5),cd2(2,6);cd2(5,1),cd2(5,2),cd2(5,5),cd2(5,6);cd2(6,1),cd2(6,2),cd2(6,5),cd2(6,6)];
sigdlt13=AS*sig13*AS';

sig14=[cd2(1,1),cd2(1,2),cd2(1,7),cd2(1,8);cd2(2,1),cd2(2,2),cd2(2,7),cd2(2,8);cd2(7,1),cd2(7,2),cd2(7,7),cd2(7,8);cd2(8,1),cd2(8,2),cd2(8,7),cd2(8,8)];
sigdlt14=AS*sig14*AS';

sig15=[cd2(1,1),cd2(1,2),cd2(1,9),cd2(1,10);cd2(2,1),cd2(2,2),cd2(2,9),cd2(2,10);cd2(9,1),cd2(9,2),cd2(9,9),cd2(9,10);cd2(10,1),cd2(10,2),cd2(10,9),cd2(10,10)];
sigdlt15=AS*sig15*AS';

sig16=[cd2(1,1),cd2(1,2),cd2(1,11),cd2(1,12);cd2(2,1),cd2(2,2),cd2(2,11),cd2(2,12);cd2(11,1),cd2(11,2),cd2(11,11),cd2(11,12);cd2(12,1),cd2(12,2),cd2(12,11),cd2(12,12)];
sigdlt16=AS*sig16*AS';

sig17=[cd2(1,1),cd2(1,2),cd2(1,13),cd2(1,14);cd2(2,1),cd2(2,2),cd2(2,13),cd2(2,14);cd2(13,1),cd2(13,2),cd2(13,13),cd2(13,14);cd2(14,1),cd2(14,2),cd2(14,13),cd2(14,13)];
sigdlt17=AS*sig17*AS';

sig25=[cd2(3,3),cd2(3,4),cd2(3,9),cd2(3,10);cd2(4,3),cd2(4,4),cd2(4,9),cd2(4,10);cd2(9,3),cd2(9,4),cd2(9,9),cd2(9,10);cd2(10,3),cd2(10,4),cd2(10,9),cd2(10,10)];
sigdlt25=AS*sig25*AS';

sig35=[cd2(5,5),cd2(5,6),cd2(5,9),cd2(5,10);cd2(6,5),cd2(6,6),cd2(6,9),cd2(6,10);cd2(9,5),cd2(9,6),cd2(9,9),cd2(9,10);cd2(10,5),cd2(10,6),cd2(10,9),cd2(10,10)];
sigdlt35=AS*sig35*AS';

sig45=[cd2(7,7),cd2(7,8),cd2(7,9),cd2(7,10);cd2(8,7),cd2(8,8),cd2(8,9),cd2(8,10);cd2(9,7),cd2(9,8),cd2(9,9),cd2(9,10);cd2(10,7),cd2(10,8),cd2(10,9),cd2(10,10)];
sigdlt45=AS*sig45*AS';

sig75=[cd2(9,9),cd2(9,10),cd2(9,13),cd2(9,14);cd2(10,9),cd2(10,10),cd2(10,13),cd2(10,14);cd2(13,9),cd2(14,10),cd2(13,13),cd2(13,14);cd2(14,9),cd2(14,10),cd2(14,13),cd2(14,14)];
sigdlt75=AS*sig75*AS';

sig65=[cd2(9,9),cd2(9,10),cd2(9,11),cd2(9,12);cd2(10,9),cd2(10,10),cd2(10,11),cd2(10,12);cd2(11,9),cd2(11,10),cd2(11,11),cd2(11,12);cd2(12,9),cd2(12,10),cd2(12,11),cd2(12,12)];
sigdlt65=AS*sig65*AS';


sdx12=sigdlt12(1,1);
sdy12=sigdlt12(2,2);
sdxy12=sigdlt12(1,2);

sdx13=sigdlt13(1,1);
sdy13=sigdlt13(2,2);
sdxy13=sigdlt13(1,2);

sdx14=sigdlt14(1,1);
sdy14=sigdlt14(2,2);
sdxy14=sigdlt14(1,2);

sdx15=sigdlt15(1,1);
sdy15=sigdlt15(2,2);
sdxy15=sigdlt15(1,2);

sdx16=sigdlt16(1,1);
sdy16=sigdlt16(2,2);
sdxy16=sigdlt16(1,2);

sdx17=sigdlt17(1,1);
sdy17=sigdlt17(2,2);
sdxy17=sigdlt17(1,2);

sdx25=sigdlt25(1,1);
sdy25=sigdlt25(2,2);
sdxy25=sigdlt25(1,2);

sdx35=sigdlt35(1,1);
sdy35=sigdlt35(2,2);
sdxy35=sigdlt35(1,2);

sdx45=sigdlt45(1,1);
sdy45=sigdlt45(2,2);
sdxy45=sigdlt45(1,2);

sdx75=sigdlt75(1,1);
sdy75=sigdlt75(2,2);
sdxy75=sigdlt75(1,2);

sdx65=sigdlt65(1,1);
sdy65=sigdlt65(2,2);
sdxy65=sigdlt65(1,2);



a=1;
db12=-1*(sdx12+sdy12);
c12=(sdx12*sdy12)-(sdxy12)^2;

db13=-1*(sdx13+sdy13);
c13=(sdx13*sdy13)-(sdxy13)^2;

db14=-1*(sdx14+sdy14);
c14=(sdx14*sdy14)-(sdxy14)^2;

db15=-1*(sdx15+sdy15);
c15=(sdx15*sdy15)-(sdxy15)^2;

db16=-1*(sdx16+sdy16);
c16=(sdx16*sdy16)-(sdxy16)^2;

db17=-1*(sdx17+sdy17);
c17=(sdx17*sdy17)-(sdxy17)^2;

db25=-1*(sdx25+sdy25);
c25=(sdx25*sdy25)-(sdxy25)^2;

db35=-1*(sdx35+sdy35);
c35=(sdx35*sdy35)-(sdxy35)^2;

db75=-1*(sdx75+sdy75);
c75=(sdx75*sdy75)-(sdxy75)^2;

db45=-1*(sdx45+sdy45);
c45=(sdx45*sdy45)-(sdxy45)^2;

db65=-1*(sdx65+sdy65);
c65=(sdx65*sdy65)-(sdxy65)^2;


syms landa1
k1=a*(landa1)^2+db12*(landa1)+c12;
k11=a*(landa1)^2+db13*(landa1)+c13;
k2=a*(landa1)^2+db14*(landa1)+c14;
k3=a*(landa1)^2+db15*(landa1)+c15;
k4=a*(landa1)^2+db16*(landa1)+c16;
k5=a*(landa1)^2+db17*(landa1)+c17;
k6=a*(landa1)^2+db25*(landa1)+c25;
k7=a*(landa1)^2+db35*(landa1)+c35;
k8=a*(landa1)^2+db45*(landa1)+c45;
k9=a*(landa1)^2+db65*(landa1)+c65;
k10=a*(landa1)^2+db75*(landa1)+c75;


f1=solve(k1);
a12=sqrt(double(max(abs(f1))));
b12=sqrt(double(min(abs(f1))));
teta12=rad2deg(atan2(2*sdxy13,(sdx12-sdy12)))/2;

f11=solve(k11);
a13=sqrt(double(max(abs(f11))));
b13=sqrt(double(min(abs(f11))));
teta13=rad2deg(atan2(2*sdxy13,(sdx13-sdy13)))/2;

f2=solve(k2);
a14=sqrt(double(max(abs(f2))));
b14=sqrt(double(min(abs(f2))));
teta14=rad2deg(atan2(2*sdxy14,(sdx14-sdy14)))/2;

f3=solve(k3);
a15=sqrt(double(max(abs(f3))));
b15=sqrt(double(min(abs(f3))));
teta15=atan2(2*sdxy15,(sdx15-sdy15))/2;

f4=solve(k4);
a16=sqrt(double(max(abs(f4))));
b16=sqrt(double(min(abs(f4))));
teta16=atan2(2*sdxy16,(sdx16-sdy16))/2;

f5=solve(k5);
a17=sqrt(double(max(abs(f5))));
b17=sqrt(double(min(abs(f5))));
teta17=atan2(2*sdxy17,(sdx17-sdy17))/2;

f6=solve(k6);
a25=sqrt(double(max(abs(f6))));
b25=sqrt(double(min(abs(f6))));
teta25=atan2(2*sdxy25,(sdx25-sdy25))/2;

f7=solve(k7);
a35=sqrt(double(max(abs(f7))));
b35=sqrt(double(min(abs(f7))));
teta35=atan2(2*sdxy35,(sdx35-sdy35))/2;

f8=solve(k8);
a45=sqrt(double(max(abs(f8))));
b45=sqrt(double(min(abs(f8))));
teta45=atan2(2*sdxy45,(sdx45-sdy45))/2;

f9=solve(k9);
a65=sqrt(double(max(abs(f9))));
b65=sqrt(double(min(abs(f9))));
teta65=atan2(2*sdxy65,(sdx65-sdy65))/2;

f10=solve(k10);
a75=sqrt(double(max(abs(f10))));
b75=sqrt(double(min(abs(f10))));
teta75=atan2(2*sdxy75,(sdx75-sdy75))/2;

X2=[XY(1,1);XY(1,2);XY(2,1);XY(2,2);XY(3,1);XY(3,2);XY(4,1);XY(4,2);XY(5,1);XY(5,2);XY(6,1);XY(6,2);XY(7,1);XY(7,2)];

x12=(X2(1,1)+X2(3,1))/2;
y12=(X2(2,1)+X2(4,1))/2;

x13=(X2(1,1)+X2(5,1))/2;
y13=(X2(2,1)+X2(6,1))/2;

x14=(X2(1,1)+X2(7,1))/2;
y14=(X2(2,1)+X2(8,1))/2;

x15=(X2(1,1)+X2(9,1))/2;
y15=(X2(2,1)+X2(10,1))/2;

x16=(X2(1,1)+X2(11,1))/2;
y16=(X2(2,1)+X2(12,1))/2;

x17=(X2(1,1)+X2(13,1))/2;
y17=(X2(2,1)+X2(14,1))/2;

x25=(X2(3,1)+X2(9,1))/2;
y25=(X2(4,1)+X2(10,1))/2;

x35=(X2(5,1)+X2(9,1))/2;
y35=(X2(6,1)+X2(10,1))/2;

x45=(X2(7,1)+X2(9,1))/2;
y45=(X2(8,1)+X2(10,1))/2;

x65=(X2(9,1)+X2(11,1))/2;
y65=(X2(10,1)+X2(12,1))/2;

x75=(X2(9,1)+X2(13,1))/2;
y75=(X2(10,1)+X2(14,1))/2;

%graph

M20=[X2(1,1) X2(2,1);X2(3,1) X2(4,1);X2(5,1) X2(6,1);X2(7,1) X2(8,1);X2(9,1) X2(10,1);X2(11,1) X2(12,1);X2(13,1) X2(14,1)];
Q20=[0 1 1 1 1 1 1;1 0 0 0 1 0 0;1 0 0 0 1 0 0;1 0 0 0 1 0 0;1 1 1 1 0 1 1;1 0 0 0 1 0 0;1 0 0 0 1 0 0];

figure(2)
gplot(Q20,M20,'-o')
hold on
k=sqrt(chi2inv(0.95,2));


%nesbi
ellipse(k*a12*10^4,b12*k*10^5,teta12,x12,y12,'b')
ellipse(k*a13*10^4,b13*k*10^5,teta13,x13,y13,'r')
ellipse(k*a14*10^4,b14*k*10^5,teta14,x14,y14,'k')
ellipse(k*a15*10^5,b15*k*10^5,teta15,x15,y15,'m')
ellipse(k*a16*10^4,b16*k*10^5,teta16,x16,y16,'g')
ellipse(k*a17*10^4,b17*k*10^5,teta17,x17,y17,'y')
ellipse(k*a25*10^4,b25*k*10^5,teta25,x25,y25,'b')
ellipse(k*a45*10^4,b45*k*10^5,teta45,x45,y45,'g')
 ellipse(k*a35*10^4,b35*k*10^5,teta35,x35,y35,'c')
 ellipse(k*a65*10^4,b65*k*10^5,teta65,x65,y65,'r')
 ellipse(k*a75*10^4,b75*k*10^5,teta75,x75,y75,'y')
xlabel('Easthing')
ylabel('Northing')
title(' graph beyzi khataye nesbi')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%project 3
Rs=eye(length(As(:,1)),length(As(:,1)))-(As*pinv(As'*ws*As)*As'*ws);  %deutum
ns=diag(abs(Rs));
mins=min(ns)
tools(1:12)=ns(1:12);
figure(5)
plot(tools,'*')

%internal reliability_MDB

Qes=Rs*pinv(ws);            %qoyud dakheli
lambda=((0.2-0.2464)/-0.0538)+7;

for j=1:length(Qes)
    for i=1:length(Qes)
    if i==j
    ci1(i,j)=1;
    else
    ci1(i,j)=0;
    end
    end
end
num_x=[];
for i=1:14
    num_x(i,1)=i;
end
for i=1:length(Qes)
lMDBs(i,1)=sqrt(abs(lambda/(ci1(i,:)*ws*Qes*ws*ci1(:,i))));
end
for i=1:length(Qes)
labla=pinv(As'*ws*As)*As'*ws*(ci1(i,:))'*lMDBs';
end

figure(3)
% gplot(Q20,M20,'-o')
% 
subplot(4,3,1)
plot(num_x,labla(:,1),'o')
subplot(4,3,2)
plot(num_x,labla(:,2),'*')
subplot(4,3,3)
plot(num_x,labla(:,3),'o')
subplot(4,3,4)
plot(num_x,labla(:,4),'o')
subplot(4,3,5)
plot(num_x,labla(:,5),'o')
subplot(4,3,6)
plot(num_x,labla(:,6),'o')
subplot(4,3,7)
plot(num_x,labla(:,7),'o')
subplot(4,3,8)
plot(num_x,labla(:,8),'o')
subplot(4,3,9)
plot(num_x,labla(:,9),'o')
subplot(4,3,10)
plot(num_x,labla(:,10),'o')
subplot(4,3,11)
plot(num_x,labla(:,11),'o')
subplot(4,3,12)
plot(num_x,labla(:,12),'o')

for i=1:12
norm_labla(1,1:12)=norm(labla(:,i));
end
num_L=[];
for i=1:12
    num_L(i,1)=i;
end
figure(4)
plot(num_L,norm_labla,'x')





%%
function h=ellipse(ra,rb,ang,x0,y0,C,Nb)
% Ellipse adds ellipses to the current plot


if nargin<1,
  ra=[];
end;
if nargin<2,
  rb=[];
end;
if nargin<3,
  ang=[];
end;

%if nargin==1,
%  error('Not enough arguments');
%end;

if nargin<5,
  x0=[];
  y0=[];
end;
 
if nargin<6,
  C=[];
end

if nargin<7,
  Nb=[];
end

% set up the default values

if isempty(ra),ra=1;end;
if isempty(rb),rb=1;end;
if isempty(ang),ang=0;end;
if isempty(x0),x0=0;end;
if isempty(y0),y0=0;end;
if isempty(Nb),Nb=300;end;
if isempty(C),C=get(gca,'colororder');end;

% work on the variable sizes

x0=x0(:);
y0=y0(:);
ra=ra(:);
rb=rb(:);
ang=ang(:);
Nb=Nb(:);

if isstr(C),C=C(:);end;

if length(ra)~=length(rb),
  error('length(ra)~=length(rb)');
end;
if length(x0)~=length(y0),
  error('length(x0)~=length(y0)');
end;

% how many inscribed elllipses are plotted

if length(ra)~=length(x0)
  maxk=length(ra)*length(x0);
else
  maxk=length(ra);
end;

% drawing loop

for k=1:maxk
  
  if length(x0)==1
    xpos=x0;
    ypos=y0;
    radm=ra(k);
    radn=rb(k);
    if length(ang)==1
      an=ang;
    else
      an=ang(k);
    end;
  elseif length(ra)==1
    xpos=x0(k);
    ypos=y0(k);
    radm=ra;
    radn=rb;
    an=ang;
  elseif length(x0)==length(ra)
    xpos=x0(k);
    ypos=y0(k);
    radm=ra(k);
    radn=rb(k);
    an=ang(k)
  else
    rada=ra(fix((k-1)/size(x0,1))+1);
    radb=rb(fix((k-1)/size(x0,1))+1);
    an=ang(fix((k-1)/size(x0,1))+1);
    xpos=x0(rem(k-1,size(x0,1))+1);
    ypos=y0(rem(k-1,size(y0,1))+1);
  end;

  co=cos(an);
  si=sin(an);
  the=linspace(0,2*pi,Nb(rem(k-1,size(Nb,1))+1,:)+1);
%  x=radm*cos(the)*co-si*radn*sin(the)+xpos;
%  y=radm*cos(the)*si+co*radn*sin(the)+ypos;
  h(k)=line(radm*cos(the)*co-si*radn*sin(the)+xpos,radm*cos(the)*si+co*radn*sin(the)+ypos);
  set(h(k),'color',C(rem(k-1,size(C,1))+1,:));

end;

end